﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projet_final_restaurant
{
    /// <summary>
    /// Logique d'interaction pour Command.xaml
    /// </summary>
    public partial class Command : Window
    {

        public Command()
        {
            InitializeComponent();
            commandMenu.DataContext= ((MainWindow)Application.Current.MainWindow).our_restoProp.list_platProp;
        }

        private void choice_menu(Object sender, SelectionChangedEventArgs e)
        {
            /*ObservableCollection<Recipe> nouvelle = new ObservableCollection<Recipe>();
            var item = (ListBox)sender;
            var choice = (Recipe)item.SelectedItem;
            MessageBox.Show("you choose " + choice.Name);*/

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Recipe commande = (Recipe)commandMenu.SelectedItem;

            bool test = ((MainWindow)Application.Current.MainWindow).our_restoProp.take_a_command(commande.Name);

            if(test)
            {
                MessageBox.Show("COMMAND IS VALID");
            }
            else
            {
                MessageBox.Show("COMMAND NOT POSSIBLE");
            }

            this.Close();
        }


    }
}
