﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projet_final_restaurant
{
    /// <summary>
    /// Logique d'interaction pour AddIng.xaml
    /// </summary>
    public partial class AddIng : Window
    {
        public AddIng()
        {
            InitializeComponent();
        }

        private void ADDING_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).our_restoProp.stock_restoProp.list_stock[0].Quantity = 15;
            ((MainWindow)Application.Current.MainWindow).our_restoProp.add_new_ingredient(nameIng.Text, Convert.ToDouble(qtyIng.Text));
            this.Close();
        }
    }
}
