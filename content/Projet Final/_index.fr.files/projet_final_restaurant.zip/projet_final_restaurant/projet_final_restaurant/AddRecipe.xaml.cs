﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projet_final_restaurant
{
    /// <summary>
    /// Logique d'interaction pour AddRecipe.xaml
    /// </summary>
    public partial class AddRecipe : Window
    {
        String command = "";
        ObservableCollection<Ingredient> nouvelle = new ObservableCollection<Ingredient>();

        public AddRecipe()
        {
            InitializeComponent();
            listIngredient.DataContext = ((MainWindow)Application.Current.MainWindow).our_restoProp.stock_restoProp.list_stock;
            listIngredientRecipe.DataContext = nouvelle;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Ingredient choice = (Ingredient)listIngredient.SelectedItem;
            choice.Quantity = Convert.ToDouble(quantity.Text);
            nouvelle.Add(choice);
            MessageBox.Show("you choose " + choice.Name);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var choice = (Ingredient)listIngredientRecipe.SelectedItem;
            nouvelle.Remove(choice);
            MessageBox.Show("you delete " + choice.Name);
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            string nameRec = nameRecipe.Text.ToString();
            double price = Convert.ToDouble(Price.Text);

            ((MainWindow)Application.Current.MainWindow).our_restoProp.list_platProp.Add(new Recipe(nameRec, price, nouvelle ));

            this.Close();
        }
    }
}
