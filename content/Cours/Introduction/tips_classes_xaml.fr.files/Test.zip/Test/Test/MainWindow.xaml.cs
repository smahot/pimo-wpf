﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace Test
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }

    public class MyClass
    {
        public MyClass()
        {
        }
        private int _MyProperty;
        public int MyProperty
        {
            get { return _MyProperty; }
            set { _MyProperty = value; }
        }
        private MyDataClass _MyDataClass;
        public MyDataClass MyClassProperty
        {
            get { return _MyDataClass; }
            set { _MyDataClass = value; }
        }
    }

    [TypeConverter(typeof(MyDataClassTypeConverter))]
    public class MyDataClass
    {
        public MyDataClass()
        {
        }
        private int _MyProperty2;
        public int MyProperty2
        {
            get { return _MyProperty2; }
            set { _MyProperty2 = value; }
        }
    }

    public class MyDataClassTypeConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type t)
        {
            if (t == typeof(String))
                return true;
            return false;
        }

        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object val)
        {
                MyDataClass temp = new MyDataClass();
                temp.MyProperty2 = Convert.ToInt32((string)val);
                return temp;
        }
    }
}
