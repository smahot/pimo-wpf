﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pendu
{
    class To_guess
    {
        public static string[] words_to_guess = { "numerique", "application", "informatique" };
        private string word_to_guess;
        private char letter_proposed;
        private string word_advance;
        private int counter;
        


        public string Initialize_word_to_guess_label()
        {
            /*
             * Initialize the text of the word_to_guess_label
             */
            this.word_advance = "";
            int len = this.Word_length;
            for (int i = 0; i < len; i++)
            {
                this.word_advance += '-';
            }
            return this.word_advance;
        }


        public bool Is_Word_Fulfilled()
        {
            return this.Word.Contains('_');
        }


        public To_guess(string value)
        {
            this.word_to_guess = value;
            Initialize_word_to_guess_label();
            this.counter = 0;

        }

        public To_guess()
        {
            this.word_to_guess = words_to_guess[1];
            Initialize_word_to_guess_label();
            this.counter = 0;
        }




        public int Counter
        {
            get
            {
                return this.counter;
            }

            set
            {
                this.counter = value;
            }
        }

        public string Word_Advance
        {
            get
            {
                return this.word_advance;
            }
            set
            {
                this.word_advance = value;
            }
        }

        public string Word 
        {
            get{
                return this.word_to_guess;
            }
            set
            {
                word_to_guess = value;
            }
        }

        public int Word_length
        {
            get
            {
                return Word.Length;
            }
        }

        public char Letter_proposed
        {
            get
            {
                return this.letter_proposed;
            }
            set
            {
                this.letter_proposed = value;
            }
        }
    }
}
